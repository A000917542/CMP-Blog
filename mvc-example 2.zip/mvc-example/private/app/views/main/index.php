<h1>Main Index</h1>
<p>This is the main page that is also the default.</p>

<a href="//www.google.ca">Google</a>